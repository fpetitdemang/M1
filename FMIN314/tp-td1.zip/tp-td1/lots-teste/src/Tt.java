
public class Tt extends T{

	public Tt(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void afficher(){
		System.out.println("Mon type dynamique : Tt\n" +
				"mon identifiant : "+identifiant);
	}

}
