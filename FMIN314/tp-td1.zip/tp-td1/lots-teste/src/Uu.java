
public class Uu extends U{

	public Uu(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void whoiam(){
		System.out.println("Mon type dynamique est : Uu\n" +
				"mon identifiant : "+identifiant);
	}	

}
