import java.util.*;



public class jeu {
	List<Commande> lHistorique;
	List<Bidon> lBidon;
	
	
	Bidon getBidon(int i){
		return lBidon.get(i);
	}

	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
