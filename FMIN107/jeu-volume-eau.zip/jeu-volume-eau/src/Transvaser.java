
public class Transvaser extends Commande {

	public Transvaser(jeu monJeux) {
		super(monJeux);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void Do() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void Undo() {
		// TODO Auto-generated method stub
		
	}

}
