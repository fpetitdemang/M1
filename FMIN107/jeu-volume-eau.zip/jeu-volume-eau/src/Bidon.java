
public class Bidon {
	
	int VolumeContenu;
	
	int getVolumeContenu(){
		return VolumeContenu;
	}

	public void vider(){
		
	}
	
	public void ajouter(int v){
		VolumeContenu = VolumeContenu + v;
	}

	public void remplir() {
		// TODO Auto-generated method stub
		
	}

}
