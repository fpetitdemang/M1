package dico;

public interface IDictionary {
	
	Object getObject(Object key);//renvoie la valeur associée à la clef
	Object putObject(Object key, Object value);
	boolean isEmpty();
	boolean constaintsKey(Object key);
	int indexOf(Object key);
	Object newIndexOf(Object key);
	int size();
		
}
