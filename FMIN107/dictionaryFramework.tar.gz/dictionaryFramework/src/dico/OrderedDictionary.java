package dico;

public class OrderedDictionary extends AbstractDictonary {
	
	public OrderedDictionary(){};
	
	public OrderedDictionary(int size){
		this.size=size;
		conteneur1 = new Object[size];
		conteneur2 = new Object[size];
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object newIndexOf(Object key) {
		if (!constaintsKey(key)){//teste si la cles n'est pas presente
			for (int i = 0; i < conteneur1.length; i++) {//cherche emplacement vide dans le conteneur
				if (conteneur1 == null)
					return i;
			}
			
			//augmente la taille des conteneurs d'une unite
			size++;
			Object tmpConteneur1[] = new Object[size];
			Object tmpConteneur2[] = new Object[size];
			for (int i = 0; i < conteneur1.length; i++) {
				tmpConteneur1[i]=conteneur1[i];
				tmpConteneur2[i]=conteneur2[i];
			}
			conteneur1=new Object[size];
			conteneur2=new Object[size];
			for (int i = 0; i < conteneur1.length; i++) {
				conteneur1[i]=tmpConteneur1[i];
				conteneur2[i]=tmpConteneur2[i];
			}
			
		}
		return newIndexOf(key);
	}

	@Override
	public Object putObject(Object key, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

  


}
