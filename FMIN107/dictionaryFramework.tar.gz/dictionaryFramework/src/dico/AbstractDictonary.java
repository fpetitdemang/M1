package dico;

public abstract class AbstractDictonary implements IDictionary {

	protected Object conteneur1[], conteneur2[];
	protected int size;
	
	public AbstractDictonary(){ this.size=0;}
	
	public int size(){
		return this.size;
	}

	
	public Object getObject(Object key){
		for (int i = 0; i < conteneur1.length; i++) 
			if (conteneur1[i]==key) return conteneur2[i]; 
		return null;
	}	
	
	/*public Object putObject(Object key, Object value){
		for (int i = 0; i < conteneur1.length; i++) {
			if(conteneur1[i]==null){
				conteneur1[i]=key;
				conteneur2[i]=value;
				return value;
			}
		}
		return null;
	}*/
	
	public int indexOf(Object key){
		for (int i = 0; i < conteneur1.length; i++) 
			if (conteneur1[i]==key) return i; 
		return -1;
	}
	
	public boolean constaintsKey(Object key){
		for (int i = 0; i < conteneur1.length; i++) 
			if (conteneur1[i]==key) return true; 
		return false;
	}
}
