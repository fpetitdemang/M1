package dico;

public class FastDictonary extends AbstractDictonary {
	
	public int size(){
		int res=0;
		for (int i = 0; i < conteneur1.length; i++) {
			if(conteneur1[i]!=null)
				res++;
		}
		return res;
	}
	
	@Override
	public boolean isEmpty() {
		if(size()==0){
			return true;}
		else {
			return false;}
	}

	@Override
	public Object newIndexOf(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object putObject(Object key, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

}
