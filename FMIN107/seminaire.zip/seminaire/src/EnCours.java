
public class EnCours extends Annulable{

	public EnCours(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
