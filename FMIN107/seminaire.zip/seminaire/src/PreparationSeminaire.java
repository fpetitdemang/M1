
public class PreparationSeminaire extends Annulable{

	public PreparationSeminaire(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
