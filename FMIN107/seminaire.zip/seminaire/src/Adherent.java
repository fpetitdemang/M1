
public class Adherent {
	String nom;
	
	public Adherent(String val){
		this.nom = val;
	}
}
