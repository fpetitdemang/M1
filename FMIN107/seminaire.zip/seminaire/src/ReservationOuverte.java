
public class ReservationOuverte extends Annulable{

	public ReservationOuverte(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	
	public void affiche() {
		System.out.println("\n\tEtat : Reservation ouverte");		
	} 
	

}
