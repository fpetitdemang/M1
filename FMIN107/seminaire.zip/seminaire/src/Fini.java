
public class Fini extends AbstractEtat{

	public Fini(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void affiche() {
		System.out.println("Etat : Fini\n");		
	} 

}
