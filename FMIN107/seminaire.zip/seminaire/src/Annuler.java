
public class Annuler extends Fini{

	public Annuler(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
