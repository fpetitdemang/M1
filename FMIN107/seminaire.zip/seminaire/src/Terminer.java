
public class Terminer extends Fini{

	public Terminer(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
