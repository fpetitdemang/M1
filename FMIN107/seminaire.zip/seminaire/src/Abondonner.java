
public class Abondonner extends Fini{

	public Abondonner(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
