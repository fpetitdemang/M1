
public class Annulable extends AbstractEtat{

	public Annulable(CycleSeminaires s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void affiche() {
		System.out.println("\n\tEtat : Annulable");		
	} 

}
