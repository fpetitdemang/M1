   //Essai modification theme
   //http://simile-widgets.org/wiki/Timeline_CreatingNewThemes
   //http://simile-widgets.org/wiki/Timeline_ThemeClass#tape
  
   var theme = Timeline.ClassicTheme.create(); // create the theme
function onLoad() {

   var eventSource = new Timeline.DefaultEventSource();


  // theme.event.instant.icon = "";//changement image icon
   theme.event.instant.icon = "images/green-circle.png";//changement image icon
	
   var bandInfos = [
     Timeline.createBandInfo({
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "70%", 
         intervalUnit:   Timeline.DateTime.MONTH,
	 theme:          theme, // Apply the theme
         intervalPixels: 100,
     }),
     Timeline.createBandInfo({
        overview:       true,//vision générale
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "30%", 
         intervalUnit:   Timeline.DateTime.MONTH, 
	 theme:          theme, // Apply the theme
         intervalPixels: 100
     })
   ];
   bandInfos[0].syncWith = 1;
   bandInfos[1].highlight = true;
   
   	         //create ( div, bandInfos[], orientation ) 
   tl = Timeline.create(document.getElementById("my-timeline"), bandInfos);
   Timeline.loadXML("example1.xml", function(xml, url) { eventSource.loadXML(xml, url); });

 }







/*function onLoad() {

   var eventSource = new Timeline.DefaultEventSource();
   
   var opinionPositif = new Timeline.DefaultEventSource();
   var opinionNeutre = new Timeline.DefaultEventSource();
   var opinionNegatif = new Timeline.DefaultEventSource();
   
   
   //changement de theme
   //http://simile-widgets.org/wiki/Timeline_CreatingNewThemes
   //http://simile-widgets.org/wiki/Timeline_ThemeClass#tape
   var theme = Timeline.ClassicTheme.create(); // create the theme
   
   
   
   var bandInfos = [
     Timeline.createBandInfo({
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "25%", 
         intervalUnit:   Timeline.DateTime.MONTH, 
         intervalPixels: 100,
     }),
     Timeline.createBandInfo({
        overview:       false,//voir les items
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "25%", 
         intervalUnit:   Timeline.DateTime.MONTH, 
         intervalPixels: 100
     }),
     Timeline.createBandInfo({
        overview:       false,
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "25%", 
         intervalUnit:   Timeline.DateTime.MONTH, 
         intervalPixels: 100
     }),
     Timeline.createBandInfo({
        overview:       true,//vision générale
         eventSource:    eventSource,
         date:           "Jun 28 2006 00:00:00 GMT",
         width:          "25%", 
         intervalUnit:   Timeline.DateTime.MONTH, 
         intervalPixels: 100
     })
   ];
   bandInfos[0].syncWith = 1;
   bandInfos[1].syncWith = 2;	
   bandInfos[2].syncWith = 3;
   bandInfos[1].highlight = true;
   
   	         //create ( div, bandInfos[], orientation ) 
   tl = Timeline.create(document.getElementById("my-timeline"), bandInfos);
   Timeline.loadXML("example1.xml", function(xml, url) { eventSource.loadXML(xml, url); });
 }*/

 /*
function onLoad() {
var eventSource = new Timeline.DefaultEventSource();
  var bandInfos = [
         Timeline.createBandInfo({
            date:           "Jun 28 2006 00:00:00 GMT",
            width:          "35%", 
            intervalUnit:   Timeline.DateTime.MONTH, 
            intervalPixels: 100,
            eventSource:    eventSource,
            zoomIndex:      10,
            zoomSteps:      new Array(
              {pixelsPerInterval: 280,  unit: Timeline.DateTime.HOUR},
              {pixelsPerInterval: 140,  unit: Timeline.DateTime.HOUR},
              {pixelsPerInterval:  70,  unit: Timeline.DateTime.HOUR},
              {pixelsPerInterval:  35,  unit: Timeline.DateTime.HOUR},
              {pixelsPerInterval: 400,  unit: Timeline.DateTime.DAY},
              {pixelsPerInterval: 200,  unit: Timeline.DateTime.DAY},
              {pixelsPerInterval: 100,  unit: Timeline.DateTime.DAY},
              {pixelsPerInterval:  50,  unit: Timeline.DateTime.DAY},
              {pixelsPerInterval: 400,  unit: Timeline.DateTime.MONTH},
              {pixelsPerInterval: 200,  unit: Timeline.DateTime.MONTH},
              {pixelsPerInterval: 100,  unit: Timeline.DateTime.MONTH} // DEFAULT zoomIndex
            )
        }),
	
		Timeline.createBandInfo({
            date:           "Jun 28 2006 00:00:00 GMT",
            width:          "35%", 
            intervalUnit:   Timeline.DateTime.MONTH, 
            intervalPixels: 100,
            showEventText:  false, 
            trackHeight:    0.5,
            trackGap:       0.2,
            eventSource:    eventSource,
            overview:       true
        }),
	

	
	
        Timeline.createBandInfo({
            date:           "Jun 28 2006 00:00:00 GMT",
            width:          "30%", 
            intervalUnit:   Timeline.DateTime.YEAR, 
            intervalPixels: 200,
            showEventText:  false, 
            trackHeight:    0.5,
            trackGap:       0.2,
            eventSource:    eventSource,
            overview:       true
        })
	

  ];
 // bandInfos[2].syncWith = 0;
//  bandInfos[1].syncWith = 2;
  bandInfos[1].highlight = true;
  
  tl = Timeline.create(document.getElementById("my-timeline"), bandInfos);
  Timeline.loadXML("example1.xml", function(xml, url) { eventSource.loadXML(xml, url); });
  
}*/
