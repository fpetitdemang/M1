<?php
session_start();
include_once 'apicaller.php';

// A completer

exit();
?>