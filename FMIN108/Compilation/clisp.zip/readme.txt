Machine virtuelle : Porlan Manuel
G�n�rateur de code : Quinta Bruno + Porlan Manuel

Fichiers :
- "gencode.lsp" : g�n�ration de code
- "mv.lsp" : machine virtuelle MV
- "readme.txt" : ce fichier
- "bench.txt" : un exemple de programme cod� en dur pour la MV
- fndebase.lsp : des exemples de fonction � charger puis ex�cuter dans la MV

Rapidement quelques exemples d' utilisation :
A la main on effectuera  :

(load "mv.lsp")
(load "gencode.lsp")

puis :

	1. interpretation du code g�n�r� sur les fonctions de base

        ;interprete du code stock� dans un fichier (deja compil�)
	(run_fic "bench.txt")

	;interprete le code avec une MV de memoire 50 en mode pas a pas
	(run_mv '( (move ($ 1) :R0 ) (incr :R0) (halt) )  50 :dbg )
	(nexti)
	(run)

	;charge du code lisp et interpr�te le code g�n�r�

	(run_mv (vm-compile '((lambda (x y) (- x y)) 15 10 )) 400 )

	ou encore (chargercode fait appel au g�n�rateur de code):

	(creer_mv 500)
	(chargercode "fndebase.lsp")
	(aff)
	(vm-apply 'fact 5)
	(vm-apply 'fibo 15)
	(vm-apply 'length ''( 1 2 3) )




	2. interpretation sur les fonctions compil�es du code des automates
	(creer_mv 10000)
	(chargercode "auto-meta.lsp")
	(vm-apply 'prop ''(:voc (a) :etats (0 1 2 3 4) :trans ((0 a 1) (1 a 2) (3 a 1) (1 a 4)) :init (0 3) :fin (2 4))) 
	(vm-apply 'normauto ''(:voc (a) :etats (0 1 2 3 4) :trans ((0 a 1) (1 a 2) (3 a 1) (1 a 4)) :init (0 3) :fin (2 4)))
	(vm-apply 'aug ''(:voc (a x y) :etats (0 1 2 3 4 5) :trans ((0 :eps 1) (1 x 3) (0 :eps 2) (2 a 4) (2 y 3) (5 :eps 0)) :init (0) :fin (3 5)))

